#Relier des variables -TDEM - TDM3 et TDM4
###########################################

######################################################################
# TDM3: Corr�lations/r�gressions: relier des variables quantitatives (2h)
######################################################################

# Corr�lations/r�gressions simples param�triques sous la forme d'une droite
    # Exo2: hu�tres perli�res
        # Question: relation entre Cd dans muscle et foie? pour toutes les donn�es
                  sent<-read.csv("sentinelle.csv", sep=";",dec=",",header=TRUE)
                  str(sent)
              x11();plot(sent$Cd_foie, sent$Cd_muscle, pch=16,cex=1.5, xlab="Cd foie", ylab="Cd muscles")
                    # Relation sous la forme d'une droite a un sens
              
         # Normalement on doit tester les conditions d'application pour un mod�le lin�aire
                    lm<-lm(Cd_muscle~Cd_foie,sent) #Etape 1: ecrire le modele
                    x11(); par(mfrow=c(2,2));plot(lm)# Etape 2: tester les CA par les graphiques 
                        # Les tests pour aider � la decision
                          library(lmtest);dwtest(lm)# independance par test de Durbin Watson => H0 accept�e, OK
                                gqtest(lm) # test de Goldfeldt-Quandt: homogeneit� des variances des residus  => H0 accept�e, OK       
                                shapiro.test(lm$res) # normalit� des r�sidus par test de Shapiro-Wilks=> pas bonne mais beaucoup de donn�es donc pas grave (>20-30)
                      # les conditions d'application sont respect�es=> modele lin�aire possible
                                
          # Test de la corr�lation de Bravais-Pearson
                cor.test(sent$Cd_muscle, sent$Cd_foie, method = "pearson") # donne r entre -1 et 1 (sens, intensit� � commenter) et p-value tr�s significative => H1 accept�e

          # Regression lin�aire simple Cd muscle en fonction de Cd foie
                anova(lm)# idem:  p-value H1 accept�e, on a le Fobs
                summary(lm)  # R2 on lit "Multiple R squared" = 99%
                # dispo des p-value sur test de pente et ordonn�e � l'origine ainsi que les valeurs par colonne "estimate"
                # Equation: Cd muslcle = 0,097Cd foie -0,216

          #Representation graphique
              x11();plot(sent$Cd_foie, sent$Cd_muscle, pch=16,cex=1.5, xlab="Cd foie", ylab="Cd muscles")
            abline(lm, col="red", lwd=2)# pour projeter la droite sur le graphique


# Corr�lations non param�triques
      #Exo1: bacteries - partie B
          #Question: Relations abdces de bact�ries et temps=> 2 variables quantitatives => corr�lations et non regression (pas de supposition si l'une explique l'autre)
                    # Je commence par observer...
                          bac<-data.frame(temps=0:6, bac=c(32,47,65,92,132,190,275))
                          str(bac)# les deux variables sont quantitatives
                        x11();plot(bac~temps,bac, ylab="Bact�ries", xlab="Temps", pch=16, cex=1.5)
                    #d'apr�s la forme de la courbe, le forme lin�aire n'a pas d'interet a �tre test�e: je cherche une relation "monotone" mais pas sous la forme d'une droite
                    # pas de conditions d'application pour les tests non param�triques de Spearman ou Kendall
                        cor.test(bac$bac, bac$temps, method = "spearman")# corr�lation de Spearman
                        cor.test(bac$bac, bac$temps, method = "kendall")# corr�lation de Mann-Kendall
                        # Ils donnent les coefficient rho (Spearman) et tau (Kendall) qui �voluent entre -1 et 1
                        # la p-value, dans les deux cas significatifs...
                        
# R�gressions multiples
            #Exo5: Huitres du bassin d'Arcachon
                  data<-read.csv("oyster2.csv",header=T,dec=",",sep=";")
                  str(data)
            #R�gression multiple
                  lm(log(Condition)~Renouvellement*Hauteur,data)->LMM
                  #V�rifier les CA:
                        x11();par(mfrow=c(2,2));plot(LMM)# avec les graphiques
                        # Avec les tests
                        gqtest(LM);shapiro.test(LM$res);dwtest(LM)# tout est OK
                  # Resultats
                        summary(LMM)#Lire le "adjusted R squared'=56%, p-value ***
                        anova(LMM) # Seul de renouvellement est significatif
                  #Pour l'�quation, autre modele necessaire avec '+'
                        lm(log(Condition)~Renouvellement+Hauteur,data)->LMM
                        summary(LMM)#LogIC=-0,107Renouv-0,07HAuteur+3,87
                        
                  # Au final seul effet de renouvellement suffit: je refais le mod�le simplement
                        lm(log(Condition)~Renouvellement,data)->LM
                        summary(LM)#Lire le "Multiple R squared'=57%, p-value ***
                        #Equation: LogIC=-0,11Renouv+3,98
                        # On remarque que les coefficients ne sont pas les m�mes: en effet pour la regression multiple
                                # le temps de renouvellement est calcul� sur les r�sidus de la hauteur et inversement (regression partielle)
                 #Representation graphique
                        x11();plot(data$Renouvellement, log(data$Condition), pch=16,cex=1.5, xlab="Renouvellement", ylab="log (IC)")
                            abline(LMM, col="red", lwd=2,lty=2)# pour projeter la droite du modele lineaire multiple sur le graphique
                            abline(LM, col="blue", lwd=2)# pour projeter la droite du modele lineaire simple avec le renouvellement seul

                            
                            
#######################################################################                                                    
# TDM4: ANOVA: relier des variables quantitatives � qualitatives (2h)
######################################################################              

# ANOVA 1 facteur
        # Exo1 - Partie A: bact�ries              
              #BDD: 1 element par ligne donc on construit la base (=>revision de la fonction data.frame et de la fonction rep())
              data<-data.frame(element=rep(c("rep1","rep2","rep3"), times=6),
                               pH=rep(c("5,3","5,8","6,3","7","7,5","8,1"),each=3),
                               bacteries=c(0,0,0,20,22,16,85,101,88,75,73,60,33,52,51,64,66,54))
              str(data)#Attention = pH doit �tre un facteur!!! C'est le cas...             
              
        # Expliquer une variable quantitative par une variable qualitative
              #=> test le plus puissant: ANOVA 1 facteur sur plan �quilibr� Y= bact et X=pH
              an<-lm(bacteries~pH,data)# Application du mod�le lin�aire ANOVA 1 facteur
              
        #Observer les donn�es
            x11();plot(bacteries~pH,data)# Boites � moustache ne se justifient pas pour 3 donn�es par condition
            library(lattice);
            x11();xyplot(bacteries~pH,data, pch=16, cex=2,col="blue")# c'est mieux!!! 
                #=>il semble y avoir des variations entre pH: on s'attend � accepter H1

        #Condition d'application sur les r�sidus
            x11(); par(mfrow=c(2,2));plot(an)
            # Tests pour aider � la decision
                shapiro.test(an$res) # test de Shapiro Wilks sur les r�sidus => H0 accept�e OK
                library(car);leveneTest(an) # test de Levene: homogeneit� des variances des residus=> OK
                  library(lmtest);dwtest(an) # Test de Durbin Watson d'independance des residus=>OK
          # CA OK je peux continuer avec un modele lin�aire

        # H0: R2 = 0; H1=R2 >0 soit au moins un de mes echantillons est diff�rent des autres
            anova(an) # tableau de analyse de variance avec Somme carr� et carr� moyen, Fobserv� et p-value
                # le test est significatif, donner la p-value => proportion d'erreur associ� au rejet H0 donc probabilit� d'avoir un resultat li� au hasard => tr�s faible donc je rejette H0
            summary(an) # on retrouve p-value, R2, F, ddl etc..
            #R2 = je lis le 'multiple R squared' soit 97%
            #Ma statistique F vaut 66,9 et mes ddl 5 

        # test post Hoc pour voir qui est diff�rent: ici plan equilibr� donc Tukey
            TukeyHSD(aov(bacteries~pH,data))# Commenter (on le fait en TD)

#Test de Kruskal-Wallis
          # Exo 3: mouches blanches
          mou<-read.csv("moucheblanche.csv", sep=";",header=TRUE)
          str(mou)
              #Representation graphique
                x11();xyplot(Mouches~Traitement,mou,pch=16, cex=2,col="blue")# plut�t qu'une bo�te � moustache car 5 replicats par condition 
                # On s'attend � difference au moins entre BAsilic et t�moin
              # Pour aplication test le plus puissant ANOVA 1 facteur
                  an<-lm(Mouches~Traitement,mou)
                  # Conditions d'application
                      x11(); par(mfrow=c(2,2));plot(an)
                                  dwtest(an) # Test de Durbin Watson d'independance des residus =>OK
                                  leveneTest(an) # test de Levene: homogeneit� des variances des residus=>pas bon et limite
                                  shapiro.test(an$res) # test de Shapiro Wilks sur les r�sidus=>bon
                  # Conclusions mitig�es: seules normalit� pas bonne de peu et on a 20 donn�es: on peut faire les 2
                       summary(an) # Pour ANOVA 1 facteur, R2=52% p-value 0,008  
                      kruskal.test(Mouches~Traitement,mou)# Pour Kruskal-Wallis p=0,02 (moins significatif), pas de R2
                  # Test post Hoc de Nemeyi pour Kruskal-Wallis
                      library(PMCMR)
                      posthoc.kruskal.nemenyi.test( mou$Mouches,mou$Traitement)# seul t�moin et basilic diff�rent

# ANOVA plusieurs facteurs sur plan �quilibr�
#####################################
          # Exo 4: crabes
                library(MASS)
                data(crabs)
                str(crabs)
      # Question: Expliquer une variable quantitative CL par deux variables qualitatives: sexe et espece
          # Type de plan: verifier avec un tableau de contingence
              table(crabs$sp,crabs$sex)
                  #=> test le plus puissant: ANOVA 2 facteurs sur plan �quilibr� 

      #Observer les r�sultats avec des boites � moustaches
          par(mfrow=c(2,2));
                  boxplot(CL~sex,crabs,main="Effet seul du sexe")
                  boxplot(CL~sp,crabs,main="Effet seul de l'esp�ce")
                  boxplot(CL~sex+sp,crabs, main="Effet combin� sexe et esp�ce")
          #Plus propre...
            library(ggplot2)
            p<-ggplot(data=crabs,aes(x=sex, y=CL,fill=sp))
          x11() ;p + geom_boxplot()+labs(x="Sexe",y="Longueur de carapace")+theme_bw()  # graphique de base stock� dans 'graphe' pour ajout de..
          # il ne semblent qu'il n'y ait pas beaucoup d'effet seul si on regarde la dispersion du sexe ou de la couleur
          #Pour observer les interactions: 
            interaction.plot(crabs$sex,crabs$sp,crabs$CL)
            #=>l'�volution selon le sexe pour les crabes orange est differnte que pour les bleus. Attention!!! la dispersion n'est pas consid�r�e

      # ANOVA 2 facteurs sur plan crois� et �quilibr�
      anm<-lm(CL~sp*sex,crabs)
        x11(); par(mfrow=c(2,2));plot(an)# Verifier les CA graphiquement
              # Test pour aider � la decision
                shapiro.test(anm$res) # test de Shapiro Wilks sur les r�sidus=>OK
                leveneTest(anm) # test de Levene: homogeneit� des variances des residus=>OK
                dwtest(anm) # Test de Durbin Watson d'independance des residus => pas bon mais graphiquement bon (il est tr�s sensible)
          # CA OK je peux continuer avec un modele lin�aire

      # H0: R2 = 0; H1=R2 >0 soit au moins un de mes echantillons est diff�rent des autres
            anova(anm) # tableau de analyse de variance avec Somme carr� et carr� moyen, Fobserv� et p-value
            # le test est significatif, pour l'espece et l'interaction mais pas pour le sexe: pour autant la variation inter-sexe est importante a considerer car l'interaction est significative
            summary(anm) # on retrouve p-value, R2, F, ddl etc..
            #R2 = je lis le 'adjusted R squared' soit 11%, significatif mais pas terrible

          # test post Hoc pour voir qui est diff�rent: ici plan equilibr� donc Tockey
            TukeyHSD(aov(CL~sex*sp,crabs))

# ANOVA plusieurs facteurs sur plan des�quilibr�
#####################################
     # Exo 4: crabes, je desequilibre le plan
            crabs2<-crabs[-c(10:15,116:118),]# au hasard j'enl�ve des �l�ments....
            table(crabs2$sp,crabs2$sex)
            #=> ANOVA 2 facteurs sur plan des�quilibr� 
            
            # ANOVA 2 facteurs sur plan crois� et �quilibr�
            anmd<-lm(CL~sp*sex,crabs2, contrasts=list(sp=contr.sum,sex=contr.sum))
            #Verifier CA...
            # H0: R2 = 0; H1=R2 >0 soit au moins un de mes echantillons est diff�rent des autres
            library(car); Anova(anmd, type="III") # tableau de analyse de variance avec Somme carr� et carr� moyen, Fobserv� et p-value
            # le test est significatif, pour tout notamment l'interaction mais pas pour le sexe: pour autant la variation inter-sexe est importante a considerer car l'interaction est significative
            summary(anmd) # on retrouve p-value, R2, F, ddl etc..
            #R2 = je lis le 'adjusted R squared' soit 12%, significatif mais pas terrible
            
            # test post Hoc: ici plan desequilibr� donc bonferroni
            crabs2$inter=paste(crabs2$sp,crabs2$sex) # creation d'une variable qualitative "interaction"
            pairwise.t.test(crabs2$CL, crabs2$inter, p.adjust="bonferroni", pool.sd = T) # juste besoin de interaction
            
            
            
#################################################
##################################
#Graphique autre si le temps...
  my.barplot <- function(data, err, ...) {
    tmp <- barplot(data, ...)
    if (length(err) != length(data))
      stop("la longueur de 'data' et 'err' ne correspond pas")
    for (i in 1:length(err))
      arrows(tmp[i],data[i]-err[i],tmp[i],data[i]+err[i],
             code=3,angle=90,length=0.08)
  }
mean<-with(crabs, tapply(CL,list(sex, sp),mean))
se<-with(crabs, tapply(CL,list(sex, sp),sd))/sqrt(with(crabs, tapply(CL,list(sex, sp),length)))
my.barplot(mean,se,xlab="Sexe",ylab="Longueur carapace", beside=T,col=c("blue","orange"))
legend("top", legend=c("Bleu", "Orange"), pch=c(15,15), col=c("blue","orange"))


   