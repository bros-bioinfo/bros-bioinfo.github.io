#COMPARAISON MOYENNES/PROPORTIONS (TDEM - TDM2 (2h) )
###########################################################

# DE MOYENNES
#############

#TEST PARAMETRIQUE
####################

#Comparer moyennes d'�chantillons ind�pendants
###############################################
      #Exo 1: hauteurs d'arbres
          #H1: F1 different de F2, test bilateral
              F1<-c(23.4, 24.4, 24.6, 24.9, 25, 26.2, 26.3, 26.8, 26.8, 26.9, 27, 27.6, 27.7)
              F2<-c(22.5, 22.9, 23.7, 24, 24.4, 24.5, 25.3, 26, 26.2, 26.4, 26.7, 26.9, 27.4, 28.5)

        #Quelques graphiques: exemple ech F1: visualiser ech et Loi normale associ�e
              hist(F1,prob=T)
                echnorm<-rnorm(100,mean=mean(F1),sd=sd(F1))#creer une echant de 100 individus suivant une Loi normale
                hist(echnorm,proba=T)
                seq<-seq(from=min(F1),to=max(F2),by=0.1)
                lines(seq,dnorm(seq, mean=mean(F1),sd=sd(F1)),col="red",lwd=2)
              
        #Tester la normalit�: test de shapiro-Wilk pour les 2 echs
                ?shapiro.test()#aide � decrire
              shapiro.test(F1)
              #Il donne la statistique calcul�, la proba exacte sous H0 p-value sur laquelle est conclue le test
              
              shapiro.test(F2)#Ech suit LN

        #Tester l'homocedasticit�: test de Fisher
            ?var.test()#aide a decrire
            var.test(F1,F2)#Var homogenes (Remarque pas m�me F trouv� parfois qu'en TD car sens s21 et s22 non impos�) mais m�me chose
            #Il donne la statistique calcul�, le ddl our le num�rateur et le denominateur, la p-value (proba exacte sous H0)
            
        #test t de Student comparaison moy ech independants / bilat�ral
              ?t.test()  # A decrire car on va se servir des diff�rents arguments
                t.test(F1,F2,alternative="two.sided",paired=FALSE, var.equal=TRUE,conf.level = 0.95)
                # les 2 echant, l'alternative (bi ou uni lateral), paired= independants (F) ou appari�s (T), var.equal=pour les variances homog�ne ou non (sinon test de Welch)
                #Il donne la statistique calcul�, le ddl, la proba exacte sous H0 p-value sur laquelle est conclue le test
                # Par definition si p<0,05 on note *, si <0.01 on note **, si <0,001 on note *** si H0 conserv�e on note ns
                # Remarque 1: m�me tcalcul� trouv� en TD a peu pr�s a cause des arrondis: Cependant t peut �tre n�gatifs car pas de valeurs absolues pris en compte ici
                # Remarque 2: il donne l'intervalle de confiance � 95% par defaut, preciser conf.level = 0.99 pour risque alpha =1%
            
            # GRaphique de repr�sentation des r�sultats sur Loi de Student
                seq<-seq(from=-3,to=3,by=0.1)
                plot(seq,dnorm(seq, mean=mean(scale(F1)),sd=sd(scale(F1))),type="l",col="black",lwd=2,ylab="Fr�quences relatives", main="L de Student")
                abline(v=c(-2,06,2.06),col="red",lwd=2)# valeur critique de t (en + et -) => celle du TD
                abline(v=0.95416,col="green",lwd=2)# valeur calcul�e de t obtenue=> conclusion H0, avec l'informatique
                #on a la vrai probabilit� sous H0
                
        #Puissance du test:
                ?power.t.test()# on precise n (le plus faible) mais pas power, d= resultat de la statistique t
                power.t.test(n=13,d=0.95416,sig.level=0.05,type="two.sample",alternative="two.sided")
                  #Puissance tr�s faible: 0,65 soit risque beta de 35% �lev� (1/3 de ne pas accept�e H1 si H1 vrai)
                #Si on voulait  une puissance de 0,9 soit risque beta de 0,10; on ne precise pas n et on donne power
                power.t.test(d=0.95416,sig.level=0.05,power=0.9,type="two.sample",alternative="two.sided")
                #il faudrait au moins 24 �l�ments par echantillons

#Comparer �chantillons � une norme
###############################################
    #Exo3: gaz Pic du midi d'Ossau
          #H1: taux<50, test unilat�ral
                G<-c(52,60.2,68.8,46.8,62.2,53.5,50.9,44.9,73.2,60.4,61.9,67.8,30.5,52.5,
                     40.4, 29.6, 58.3, 62.6, 53.6, 64.6, 54.4, 53.8, 49.8, 57.4, 63.1, 53.4, 59.4,
                     48.6, 40.7, 51.9)
  
                shapiro.test(G)#suit LN => test param�trique possible
                t.test(G,mu=50, alternative="less") # l'�chantillon, la norme
                        # Attention!!! ici unilateral donc alternative soit less soit greater premier par rapport au second
                        # ici G<mu donc "less"
                #Pour la puissance: power.t.test()
                
                
#Comparer des �chantillons appari�s
###############################################              
    #Exo4: MES
          #H1: P1>P2, comparaison d'�chantillons appari�s, unilateral
                P1<-c(22, 26, 28.5,19.3,32.6,34.9,21.8,23.8,27.9,32.5)
                P2<-c(22.5, 25, 28, 19.3, 28.6, 34.8, 17.3, 24.0, 25.0, 30.9)
                P=P1-P2 # Attention!!! test de normalit� sur les diff�rences
                shapiro.test(P)#differences suit LN
                t.test(P1,P2, paired=TRUE, alternative="greater") #Unilat�ral avec P1>P2 donc greater            
                #Pour la puissance: power.t.test()                

                
#TEST NON PARAMETRIQUE
####################  
#Comparer moyennes d'�chantillons ind�pendants
############################################### 
      #Exo2: Coucou gris
          #�R<�F => test unilat�ral
                R<-c(18.4, 22.1, 21.5, 20.9, 22, 21, 22.3, 21, 20.3, 20.9, 22, 22, 20.8, 21.2, 21)
                F<-c(27.2, 24, 26, 27.5, 30, 32, 25.7, 28.5, 28, 23.1, 29.2, 23, 21, 29.5)
                shapiro.test(R)#pas de LN
                shapiro.test(F)#Ech suit LN
                # au moins un des deux ne suit pas LN donc test de WMW
                ?wilcox.test()# decrire des arguments important
                wilcox.test(R,F,paired=FALSE, alternative="less")
                #Remarque: On retrouve la m�me valeur de statistique qu'en TD
                #Remarque: Pour la puissance du test: pas de moyen simple de calculer mais toujours < au test param�trique correspondant
                
#Comparer moyenne � une norme
############################################### 
      #Exo5: geologue
                #H1: constante differente de Pi, test bilateral
                G<-c(3.23, 3.28, 4.10, 3.23)
                shapiro.test(G)#ne suit pas LN: on aurait pu s'en douter vu le nombre d'�l�ments dans l'�chantillon!!!
                wilcox.test(G,mu=3.14,alternative="two.sided")
                
                
#Comparer moyennes d'�chantillons ind�pendants
###############################################               
      #Exo6: hu�tres perli�res
                sent<-read.csv("sentinelle.csv", sep=";",header=TRUE,dec=",")
                str(sent)
                
                #Q2: H1: diff (muscles-foie) < 0=> unilat�ral
                Muscle<-subset(sent,Lieu=="Port","Cd_muscle")
                foie<-subset(sent,Lieu=="Port","Cd_foie")
                d<-(Muscle[,1]-foie[,1])
                str(d)
                shapiro.test(d)#ne suit pas LN: on aurait pu s'en douter vu le nombre d'�l�ments dans l'�chantillon!!!
                wilcox.test(Muscle[,1],foie[,1],alternative="less")
 
 # DE PROPORTIONS
####################                
      #Q1: H1: prop diff entre Port et Vairao      
                table(sent$Lieu,sent$Espece)->tab  #CA respect�es >5 par modalit�s crois�s
                plot(tab)
                chisq.test(tab) #test du chi2 (m�me resultat qu'en TD)
                #Si condition pas respect�es: test exact de Fisher
                  fisher.test(tab) #m�me resultats

#Faire tout seul les autres exos du TD: 7,8,9
          #Exo7: vigne
                  #H1: �chevalier differents �couhins, test bilat�ral
                  C1<-c(1.08, 7.68, 8.28, 8.23, 7.63, 11.74, 11.3, 11.72, 10.87, 9.02)
                  C2<-c(5.45, 6.89, 9.45, 3.03, 8.23, 6.12, 5.98, 4.32, 7.63, 3.21)
                  shapiro.test(C1)#ne suit pas LN
                  shapiro.test(C2)#Ech suit LN
                  wilcox.test(C1,C2,alternative="two.sided",paired=FALSE)
          #Exo8: Methode trigo
                  M1<-c(20.4, 25.4, 25.6, 25.6, 26.6, 28.6, 28.7, 29, 29.8, 30.5, 30.9, 31.1)
                  M2<-c(18.5, 26.3, 26.8, 28.1, 26.2, 27.3, 29.5, 32, 30.9, 32.3, 32.3, 31.7)
                  #Test 1: H1: M1<M2 test ech appari�s, unilat�ral
                  M=M2-M1
                  shapiro.test(M)#suit LN
                  t.test(M1,M2, paired=TRUE, alternative="less")
          #Exo9: Granulo
                  #...cnstruire table avec data.frame
                  